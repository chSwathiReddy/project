package com.justeat.pizzaorder.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.justeat.pizzaorder.bean.Customer;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.bean.PizzaOrder;

public class pizzaorderDAO {
	@Autowired
	private	 SessionFactory sessionFactory;
	 public String validate(Login login){
		 Session session=sessionFactory.openSession();
		 String hql="from Login where uname=:username and pwd=:password";
		 Query query=session.createQuery(hql);
		 query.setParameter("username",login.getUname());
		 query.setParameter("password", login.getPwd());
		 List list=query.getResultList();
		 if(list.size()==0){
			 return "failure";
		 }
			 else
				 return "success";
		 }
	 public int placeOrder(Customer customer,PizzaOrder pizza){
		 Session session=sessionFactory.openSession();
		 Transaction tx=session.beginTransaction();
		 pizza.setCustomerId(customer);
		 session.save(pizza);
		 int pid=pizza.getOrderId();
		 System.out.println("pid:"+pid);
		 tx.commit();
		 session.close();
		 return pid;
	 }
	 }

