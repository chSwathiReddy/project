package com.justeat.pizzaorder.topping;

import java.util.HashMap;

public class PizzaToppings {
private static HashMap<Integer,String> toppings=new HashMap();
public static HashMap<Integer,String> getToppings(){
	toppings.put(30,"Capsicum");
	toppings.put(50,"Mushroom");
	toppings.put(70,"Jalapeno");
	toppings.put(85,"Paneer");
	return toppings;
}
}
