package com.justeat.pizzaorder.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.justeat.pizzaorder.bean.Customer;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.bean.PizzaOrder;
import com.justeat.pizzaorder.topping.PizzaToppings;
import com.justeat.pizzaorder.service.pizzaorderService;
import com.justeat.pizzaorder.dao.pizzaorderDAO;


@Controller
public class LoginController {
	@Autowired
	private pizzaorderService pizzaorderService;
	@Autowired
	private PizzaOrder pizzaOrder;
	@RequestMapping("login")
	public String login(Model m)
	{
		
		m.addAttribute("loginBean", new Login());
		return "login";
	}

	@RequestMapping("validate")
	public String validate(@Valid @ModelAttribute("loginBean")Login login,Model m)
	{
		
		String res=pizzaorderService.validate(login);
		if(res.equals("success"))
			return "homepage";
		else
			return "failure";
	}
	
	HashMap hm=new HashMap();
	@RequestMapping("placeController")
	public String getToppings(Model m){
		hm=PizzaToppings.getToppings();
		System.out.println("hm:"+hm);
		m.addAttribute("pizzaToppings", hm);
		m.addAttribute("customer", new Customer());
		return "placeorder";
	}
	@RequestMapping(value="/saveorderController")
	public String saveOrder(@RequestParam("topping")int topping,Model m,@Valid @ModelAttribute("customer")Customer customer,BindingResult br)
	{
		int pid=pizzaorderService.placeOrder(customer,pizzaOrder,topping);
		m.addAttribute("pid",pid);
		if(br.hasErrors()){
			m.addAttribute("pizzaToppings", hm);
			return "placeorder";
		}
		else
			return "success";
		}
	}
