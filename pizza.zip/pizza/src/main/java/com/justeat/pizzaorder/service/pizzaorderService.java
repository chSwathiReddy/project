package com.justeat.pizzaorder.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.justeat.pizzaorder.bean.Customer;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.bean.PizzaOrder;
import com.justeat.pizzaorder.topping.PizzaToppings;
import com.justeat.pizzaorder.dao.pizzaorderDAO;
public class pizzaorderService {
@Autowired
pizzaorderDAO pizzaorderdao;
public String validate(Login login){
	String res=pizzaorderdao.validate(login);
	return res;
}
@Autowired
private PizzaOrder pizzaOrder;
public int placeOrder(Customer customer,PizzaOrder pizza,int topping){
	int totalprice=0;
	totalprice=350+topping;
	pizza.setTotalPrice(totalprice);
	int k=pizzaorderdao.placeOrder(customer, pizza);
	return k;
}
}
